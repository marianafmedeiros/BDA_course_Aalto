library(testthat)
library(aaltobda)

test_check("aaltobda")
